# EvolClaw 图片支持功能故障报告

## 问题概述
飞书图片消息功能实现完成，但在实际运行中遇到 API 400 错误，导致图片无法被 Claude 正确识别。

## 技术实现状态

### ✅ 已完成的功能
1. **图片下载**：成功从飞书 API 下载图片（使用 im.messageResource.get）
2. **Base64 转换**：正确将图片转换为 base64 格式
3. **MessageStream 实现**：按照 HappyClaw 标准实现了 AsyncIterable<SDKUserMessage>
4. **消息格式**：符合 Anthropic API 规范的 image content block
5. **文本消息**：完全正常工作，会话连续性正常

### ❌ 故障现象
- **错误信息**：`API Error: 400 请求体异常`
- **触发条件**：发送包含图片的消息时
- **错误位置**：Claude Agent SDK 调用 API 时返回
- **频率**：几乎每次（仅有一次例外）

### 🔍 关键发现
**唯一成功案例**：在会话触发自动压缩（compact）后，发送图片成功被识别：
> "我看到你给我发了4张图片，展示的是同一张照片...这看起来像一台迷你电脑..."

**失败案例**：压缩前后的其他所有尝试均失败

## 技术细节

### 代码实现（与 HappyClaw 一致）
```typescript
// message-stream.ts
content = [
  { type: 'text', text },
  ...images.map((img) => ({
    type: 'image' as const,
    source: {
      type: 'base64' as const,
      media_type: img.mimeType || 'image/png',
      data: img.data,  // base64 字符串
    },
  })),
];
```

### API 调用配置
- **Base URL**: `https://mg.aid.pub/claude-proxy`
- **SDK**: `@anthropic-ai/claude-agent-sdk`
- **Resume 参数**：已尝试启用/禁用，均失败

### 日志示例
```
[Feishu] Image downloaded successfully, size: 167420
[AgentRunner] Creating query with images, images: 1
[MessageStream] Creating multimodal message with 1 images
[MessageStream] Image sizes: 167420
[Feishu] Got result: API Error: 400 请求体异常
```

## 对比分析

### HappyClaw 项目
- 使用相同的 API 代理（`https://mg.aid.pub/claude-proxy`）
- 使用相同的 MessageStream 实现
- **同样存在图片 400 错误问题**

### 差异点
- HappyClaw 使用 `resumeSessionAt` 参数（我们未使用）
- HappyClaw 在容器环境中运行（我们直接运行）

## 可能原因分析

### 1. API 代理限制（最可能）
- 代理可能不支持图片内容
- 代理可能对请求体大小有限制
- 代理的 API 版本可能不支持多模态消息

### 2. 会话状态冲突
- 压缩后成功说明"干净"的会话状态可以工作
- 但即使不使用 resume 参数也失败，说明不完全是会话问题

### 3. SDK 版本兼容性
- 可能需要特定版本的 SDK
- 可能需要特定的配置参数

## 建议行动

### 短期方案
1. **验证代理支持**：联系 `mg.aid.pub` 确认是否支持 Claude Agent SDK 的图片功能
2. **测试官方 API**：临时切换到官方 API 测试图片功能是否正常
3. **降级方案**：提示用户将图片保存到服务器，通过文件路径让 Claude 使用 Read 工具读取

### 长期方案
1. 如果代理不支持，考虑：
   - 切换到支持图片的代理
   - 或直接使用官方 API
2. 如果是 SDK 问题，考虑：
   - 升级/降级 SDK 版本
   - 使用不同的 API 调用方式

## 当前状态
- **文本功能**：✅ 完全正常
- **图片功能**：⚠️ 实现完成但受限于 API 问题
- **代码质量**：✅ 符合最佳实践

## 附录：测试图片信息
- **格式**：PNG
- **Base64 大小**：167420 字符
- **来源**：飞书消息附件
- **下载方式**：im.messageResource.get API

---
报告生成时间：$(date '+%Y-%m-%d %H:%M:%S')
