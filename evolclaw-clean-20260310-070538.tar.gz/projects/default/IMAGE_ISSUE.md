# EvolClaw 图片支持故障

## 问题
飞书图片消息实现完成，但遇到 `API Error: 400 请求体异常`

## 状态
- ✅ 图片下载、Base64转换、消息格式正确
- ✅ 文本消息正常
- ❌ 图片消息几乎总是失败
- ✅ 唯一成功：会话压缩后发送图片成功

## 代码实现
```typescript
content = [
  { type: 'text', text },
  ...images.map((img) => ({
    type: 'image',
    source: {
      type: 'base64',
      media_type: img.mimeType || 'image/png',
      data: img.data,
    },
  })),
];
```

## 可能原因
1. **API代理限制**（最可能）- `mg.aid.pub/claude-proxy` 可能不支持图片
2. 会话状态冲突
3. SDK版本兼容性

## 对比
HappyClaw 使用相同代理也存在同样问题

## 建议
- 验证代理是否支持图片功能
- 测试官方 API
- 或使用降级方案：提示用户保存图片到服务器，通过文件路径读取
