import { query } from '@anthropic-ai/claude-agent-sdk';

// 测试 systemPrompt.append 功能
async function testSystemPrompt() {
  console.log('Testing systemPrompt.append...\n');

  const stream = query({
    prompt: '你好',
    options: {
      cwd: '/home/evolclaw',
      systemPrompt: {
        type: 'preset',
        preset: 'claude_code',
        append: '[测试] 请在回复中提到"系统提示已生效"这几个字。'
      },
      env: {
        ...process.env,
        ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY
      }
    }
  });

  let response = '';
  for await (const event of stream) {
    if (event.type === 'text_delta') {
      response += event.text;
      process.stdout.write(event.text);
    }
  }

  console.log('\n\n--- 测试结果 ---');
  if (response.includes('系统提示已生效')) {
    console.log('✅ systemPrompt.append 工作正常');
  } else {
    console.log('❌ systemPrompt.append 可能未生效');
    console.log('响应内容:', response);
  }
}

testSystemPrompt().catch(console.error);
